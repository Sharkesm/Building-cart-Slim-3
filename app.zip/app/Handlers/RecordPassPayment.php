<?php


namespace Cart\Handlers;

use Cart\Handlers\Contracts\HandlerInterface;

/**
 *
 */
class RecordPassPayment implements HandlerInterface
{


  protected $transactionId;

  public function __construct($transactionId){

        $this->transactionId = $transactionId;
  }


  public function handle($event){

    $event->order->payment()->create([

          'failed' => true,
          'transaction_id' => $this->transactionId
    ]);

  }

}
