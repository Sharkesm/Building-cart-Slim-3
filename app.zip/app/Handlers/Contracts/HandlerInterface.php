<?php


namespace Cart\Handlers\Contracts;


interface HandlerInterface {

  public function handle($event);

}
